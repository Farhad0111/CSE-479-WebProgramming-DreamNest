### In the `server` folder, create a file named `.env` and write the followings.

- MONGO_URL=PUT_YOUR_MONGO_DATABASE_URL_HERE
- JWT_SECRET=PUT_ANY_SECRET_TEXT_FOR_TOKEN_GENERATION

### Start the **BACKEND SERVER** by going into the **server** folder and run `npm start` cmd.
### Start the **FRONTEND** by going into the **client** folder and run `npm start` cmd.